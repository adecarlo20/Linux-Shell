Antonio DeCarlo - Lab 1 - Linux Shell
1). To complie my code I used gcc main(4)(1).c and then \a.out.

2). To use my shell, there are different commands. If one needs help, they can go to
    the user manual, where it displays those commands and how to call them. There is the 
    C command, which is used for copying one file to the next, the D command which deletes 
    a file, the E command which prints the arugument followed by a space (if not empty), the
    H command which displays the user manual, the L command which lists the content of the
    directory, the M command which opens that file in the text editor, the P command which 
    prints, the Q command which exits the shell, the S command which launches firefox in the background, 
    the W command which clears the screen, and the X command which launches a specific program.

3). For my shell, there are 3 functions names parseCommand, printPrompt, and readCommand. 
    For the different commands I used cases for each letter, using execvp in each case to make it
    easy doing basic commands on files. For my printPrompt, I created a char array named promptString, 
    and  within that array inputed my UAKRON user id for the shells name.

4). When I was stuck, I would use some helpful websites like stackoverflow.com, geeksforgeeks.org, 
    and unix.com. 