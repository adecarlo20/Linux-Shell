// ACADEMIC INTEGRITY PLEDGE
//
// - I have not used source code obtained from another student nor
//   any other unauthorized source, either modified or unmodified.
//
// - All source code and documentation used in my program is either
//   my original work or was derived by me from the source code
//   published in the textbook for this course or presented in
//   class.
//
// - I have not discussed coding details about this project with
//   anyone other than my instructor. I understand that I may discuss
//   the concepts of this program with other students and that another
//   student may help me debug my program so long as neither of us
//   writes anything during the discussion or modifies any computer
//   file during the discussion.
//
// - I have violated neither the spirit nor letter of these restrictions.
//
//
//
// Signed:________Antonio DeCarlo______________ Date:03/01/2023

// 3460:426 Lab 1 - Basic C shell rev. 9/10/2020

/* Basic shell */

/*
 * This is a very minimal shell. It finds an executable in the
 * PATH, then loads it and executes it (using execv). Since
 * it uses "." (dot) as a separator, it cannot handle file
 * names like "minishell.h"
 *
 * The focus on this exercise is to use fork, PATH variables,
 * and execv.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdbool.h>

#define MAX_ARGS		64
#define MAX_ARG_LEN		16
#define MAX_LINE_LEN	80
#define WHITESPACE		" ,\t\n"

struct command_t {
    char* name;
    int argc;
    char* argv[MAX_ARGS];
};

/* Function prototypes */
int parseCommand(char*, struct command_t*);
void printPrompt();
void readCommand(char*);

int main(int argc, char* argv[]) {
    int pid;
    bool lp = 1;
    int pidFirefox = 0;
    int position;
    char cmdLine[MAX_LINE_LEN];
    struct command_t command;

    while (lp) {
        printPrompt();
        /* Read the command line and parse it */
        readCommand(cmdLine);
        parseCommand(cmdLine, &command);
        command.argv[command.argc] = NULL;



        /* Create a child process to execute the command */
        if ((pid = fork()) == 0) {             /* Child executing command */
            switch (command.argv[0][0])
            {
            case 'C': // this is the copy case, using arguments 1 and 2
                execvp("cp", (char* []) { "cp", command.argv[1], command.argv[2], NULL });
                return 0;

            case 'D': // this is the remove case
                execvp("rm", (char* []) { "rm", command.argv[1], NULL });
                return 0;

            case 'E': // this is the echo case
                for (int i = 1; i < command.argc; ++i)            // print the argument followed by a space if not an empty string
                    if (command.argv[i][0] != '\0')
                        printf("%s ", command.argv[i]);
                printf("\n");
                return 0;

            case 'H': // this is the user manual/menu case
                printf(  
                    "             Menu of the shell. Type a command -> C - D - E - H - L - M - P - S - W- X           \n"
                    " The C command is used for copying a file, which requires two arguments(used file and new file)  \n"
                    "                     The D command is used for deleting files you need removed.                  \n"
                    "               The E (echo) command displays comment on screen followed by a new line.           \n"
                    "             The H command will display the menu of this shell, which is used for help.          \n"
                    "           The L command lists all the content inside the directory currently being used.        \n"
                    "              The M command takes a file inputed and launches it in the text editor.             \n"
                    "           The P command takes a file and prints the content isndie that file on screen.         \n"
                    "                                 The Q command exits the shell.                                  \n"
                    "                         The S command opens Firefox in the background.                          \n"
                    "                               The W command clears the screen.                                  \n"
                    "                          The X command will execute the named program.                          \n"
                    );
                return 0;

            case 'L': // this is the list case
                printf("\n");
                if (fork() == 0)
                    execvp("pwd", (char* []) { "pwd", NULL });
                wait(0);
                printf("\n");
                execvp("ls", (char* []) { "ls", "-l", NULL });
                return 0;

            case 'M': // this is the text editor case
                execvp("nano", (char* []) { "nano", command.argv[1], NULL });
                return 0;

            case 'P':  // this is the print case
                execvp("more", (char* []) { "more", command.argv[1], NULL });
                return 0;

            case 'S':  // this is the firefox case
                pidFirefox = getpid();
                execvp("firefox", (char* const []) { "firefox", NULL });
                return 0;

            case 'W':  // this is the clear case
                execvp("clear", (char* []) { "clear", NULL });
                return 0;

            case 'X': // this is the execute case
                execvp(command.argv[1], (char* []) {command.argv[1], NULL });
                return 0;

                /* TODO: what happens if you enter an incorrect command? */
            default:
                execvp(command.argv[0], command.argv);
                return 0;
            }
        }

     

        /* Wait for the child to terminate */
        if (pid > 0) {
            if (command.name[0] !='S') waitpid(pid, &position, 0);
        }
        else {
            printf("Fork did not work :( \n");
        }

        /* Shell termination */
        if (command.argv[0][0] == 'Q') {
            printf("\n\n shell: Terminating successfully\n");
            return 0;
        }
    }
return 0;
}

/* End basic shell */

/* Parse Command function */

/* Determine command name and construct the parameter list.
 * This function will build argv[] and set the argc value.
 * argc is the number of "tokens" or words on the command line
 * argv[] is an array of strings (pointers to char *). The last
 * element in argv[] must be NULL. As we scan the command line
 * from the left, the first token goes in argv[0], the second in
 * argv[1], and so on. Each time we add a token to argv[],
 * we increment argc.
 */
int parseCommand(char* cLine, struct command_t* cmd) {
    int argc;
    char** clPtr;
    /* Initialization */
    clPtr = &cLine;	/* cLine is the command line */
    argc = 0;
    cmd->argv[argc] = (char*)malloc(MAX_ARG_LEN);
    /* Fill argv[] */
    while ((cmd->argv[argc] = strsep(clPtr, WHITESPACE)) != NULL) {
        cmd->argv[++argc] = (char*)malloc(MAX_ARG_LEN);
    }

    /* Set the command name and argc */
    cmd->argc = argc - 1;
    cmd->name = (char*)malloc(sizeof(cmd->argv[0]));
    strcpy(cmd->name, cmd->argv[0]);
    return 1;
}

/* End parseCommand function */

/* Print prompt and read command functions - Nutt pp. 79-80 */

void printPrompt() {
    char promptString[20] = "ajd190's Linux Shell"; 
    printf("%s ", promptString);
}

void readCommand(char* buffer) {
    /* This code uses any set of I/O functions, such as those in
     * the stdio library to read the entire command line into
     * the buffer. This implementation is greatly simplified,
     * but it does the job.
     */
    fgets(buffer, 80, stdin);
}

/* End printPrompt and readCommand */